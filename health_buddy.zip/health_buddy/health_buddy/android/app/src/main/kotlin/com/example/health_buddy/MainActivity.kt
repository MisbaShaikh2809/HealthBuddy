package com.example.health_buddy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
