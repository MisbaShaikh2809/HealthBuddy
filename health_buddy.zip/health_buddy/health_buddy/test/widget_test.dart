import 'package:health_buddy/constants/descriptions.dart';

void main() {
  print(getMedicines());
}
