import 'package:flutter/material.dart';
import 'package:health_buddy/constants/colors.dart';
import 'package:health_buddy/widgets/affected_disease_card.dart';

import '../../utils/responsive.dart';

class AffectDiseases extends StatelessWidget {
  const AffectDiseases({super.key, required this.diseases});
  final List<String> diseases;

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height * 0.01;

    return Scaffold(
        backgroundColor: kPrimaryDark,
        body: SafeArea(
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.all(0),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(Icons.arrow_back_ios),
                  ),
                ],
              ),
              Container(
                height: height * 3,
              ),
              const SizedBox(
                height: 20,
              ),
              Text(
                "Affected Diseases",
                style: TextStyle(
                    fontSize: getHeadingSize(context),
                    color: Colors.white,
                    fontWeight: FontWeight.w600),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(
                height: 30,
              ),
              //CARDS
              ListView.builder(
                shrinkWrap: true,
                itemCount: diseases.length,
                itemBuilder: (context, index) {
                  return AffectedDiseaseCard(
                    diseaseName: diseases[index],
                  );
                },
              )
            ],
          ),
        ));
  }
}
