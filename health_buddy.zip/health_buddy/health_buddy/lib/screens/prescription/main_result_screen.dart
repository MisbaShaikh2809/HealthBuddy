import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:health_buddy/constants/colors.dart';
import 'package:health_buddy/screens/prescription/affect_diseases.dart';
import 'package:health_buddy/screens/prescription/dosage.dart';
import 'package:health_buddy/screens/prescription/generic_medicine.dart';
import 'package:health_buddy/screens/prescription/info_medicine.dart';
import 'package:health_buddy/services/api_service.dart';
import 'package:health_buddy/services/database_service.dart';
import 'package:health_buddy/services/network_status_service.dart';
import 'package:health_buddy/utils/responsive.dart';
import 'package:image_cropper/image_cropper.dart';

import '../../models/result_model.dart';

class MainPrescriptionScreen extends StatefulWidget {
  final CroppedFile? image;
  final String? pred;

  const MainPrescriptionScreen({super.key, required this.image, this.pred});

  @override
  State<MainPrescriptionScreen> createState() => _MainPrescriptionScreenState();
}

class _MainPrescriptionScreenState extends State<MainPrescriptionScreen> {
  bool isLoading = false;
  bool isSaved = false;

  //save prescription into local
  Future<int> saveData(String data) async {
    setState(() {
      isLoading = true;
    });
    //insert into database
    String time = DateTime.now().millisecondsSinceEpoch.toString();
    int id = int.parse(time);
    int savedID = await ResultModel(id: id, prescription: data, timestamp: time)
        .insertData();

    setState(() {
      isLoading = false;
    });

    return savedID;
  }

  @override
  Widget build(BuildContext context) {
    var navigator = Navigator.of(context);
    final height = MediaQuery.of(context).size.height * 0.01;
    return Connect(
      child: Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            //get data here
          },
        ),
        backgroundColor: kPrimaryDark,
        body: FutureBuilder<String>(
            future: Api().extractTextFromImage(widget.image!.path),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                String text = snapshot.data!;
                return SafeArea(
                    child: ListView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 25, vertical: 20),
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.all(0),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: const Icon(Icons.arrow_back_ios),
                        ),
                        //save button
                        GestureDetector(
                          onTap: () async {
                            if (isSaved == false) {
                              await saveData(text).then((value) {
                                //Show snackbar
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Result saved successfully'),
                                  ),
                                );
                              });
                              setState(() {
                                isSaved = true;
                              });
                            } else {
                              //Show snackbar
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Result already saved'),
                                ),
                              );
                            }
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: ksecondaryDark,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.all(10),
                            child: isSaved == true
                                ? const Icon(Icons.bookmark)
                                : const Icon(Icons.bookmark_outline),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    const Text(
                      'Scanned',
                      style: TextStyle(fontSize: 20, color: Colors.grey),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(
                      "Scanned Prediction",
                      style: TextStyle(
                          fontSize: getHeadingSize(context),
                          color: Colors.white,
                          fontWeight: FontWeight.w600),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Text(
                      text,
                      style: TextStyle(
                        fontFamily: 'Sora',
                        fontSize: height * 2.2,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    FutureBuilder<List<Map<String, dynamic>>>(
                        future: Db().getMostProbableDisease(text),
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            var data = snapshot.data!;
                            if (data.isEmpty) {
                              return const Center(
                                child: CircularProgressIndicator(),
                              );
                            }
                            return Column(
                              children: [
                                //TOP
                                Container(
                                  margin:
                                      const EdgeInsets.symmetric(vertical: 10),
                                  height: 100,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      InfoCard(
                                        icon: Icons.view_agenda,
                                        color: kGreen,
                                        title: "Probable Disease",
                                        onPressed: () {
                                          List<String> diseases = [];
                                          for (var i = 0;
                                              i < data.length;
                                              i++) {
                                            diseases.add(
                                                data[i]['Suggest Disease']);
                                          }

                                          navigator.push(
                                            MaterialPageRoute(
                                              builder: (context) =>
                                                  AffectDiseases(
                                                diseases: diseases,
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                      const SizedBox(
                                        width: 20,
                                      ),
                                      InfoCard(
                                        icon: Icons.medical_information,
                                        color: kblue,
                                        title: "Information of medicines",
                                        onPressed: () {
                                          navigator.push(
                                            MaterialPageRoute(
                                              builder: (context) =>
                                                  InfoMedicine(
                                                info: data,
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                                //BOTTOM
                                Container(
                                  margin:
                                      const EdgeInsets.symmetric(vertical: 10),
                                  height: 100,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      InfoCard(
                                        icon: Icons.other_houses,
                                        color: kred,
                                        title: "Suggest Generic Medicines",
                                        onPressed: () {
                                          //Get generic medicines
                                          List medicines = [];
                                          for (var i = 0;
                                              i < data.length;
                                              i++) {
                                            medicines.addAll(
                                                data[i]['Generic Name']);
                                          }
                                          navigator.push(
                                            MaterialPageRoute(
                                              builder: (context) =>
                                                  GenericMedicine(
                                                medicineList: medicines,
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                      const SizedBox(
                                        width: 20,
                                      ),
                                      InfoCard(
                                        icon: Icons.percent_rounded,
                                        color: korange,
                                        title: "Dosage",
                                        onPressed: () {
                                          navigator.push(
                                            MaterialPageRoute(
                                              builder: (context) => Dosage(
                                                info: data,
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            );
                          } else {
                            return const Center(
                              child: CircularProgressIndicator(),
                            );
                          }
                        }),
                  ],
                ));
              } else {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }
            }),
      ),
    );
  }
}

class InfoCard extends StatelessWidget {
  const InfoCard({
    Key? key,
    required this.title,
    required this.color,
    required this.icon,
    required this.onPressed,
  }) : super(key: key);

  final String title;
  final Color color;
  final IconData icon;
  final void Function() onPressed;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 3,
      child: GestureDetector(
        onTap: onPressed,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Center(
                  child: Icon(icon, color: Colors.white, size: 30),
                ),
              ),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
