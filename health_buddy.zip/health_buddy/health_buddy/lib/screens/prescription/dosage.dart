import 'package:flutter/material.dart';
import 'package:health_buddy/constants/colors.dart';
import 'package:health_buddy/utils/responsive.dart';
import 'package:health_buddy/utils/string_opration.dart';
import 'package:health_buddy/widgets/info_card.dart';

class Dosage extends StatefulWidget {
  const Dosage({super.key, required this.info});
  final List<Map<String, dynamic>> info;

  @override
  State<Dosage> createState() => _DosageState();
}

class _DosageState extends State<Dosage> {
  List medicineName = [];
  List medicineInfo = [];

  @override
  void initState() {
    super.initState();
    for (int i = 0; i < widget.info.length; i++) {
      List medicines = widget.info[i]["Medicine Name"];
      List info = widget.info[i]["Dosage"];
      medicineName.addAll(medicines);
      medicineInfo.addAll(info);
    }
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height * 0.01;

    return Scaffold(
      backgroundColor: kPrimaryDark,
      body: SafeArea(
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.all(0),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(Icons.arrow_back_ios),
                ),
              ],
            ),
            Container(
              height: height * 3,
            ),
            const SizedBox(
              height: 20,
            ),
            Text(
              "Dosage",
              style: TextStyle(
                  fontSize: getHeadingSize(context),
                  color: Colors.white,
                  fontWeight: FontWeight.w600),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(
              height: 30,
            ),
            //CONTENT
            // Text(
            //   widget.content,
            //   style: TextStyle(
            //     fontSize: height * 2.3,
            //     fontWeight: FontWeight.bold,
            //   ),
            // ),
            //CONTENT
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: medicineName.length,
              itemBuilder: (context, index) {
                return InfoCard(
                    title:
                        '${index + 1}. ${medicineName[index].toString().toTitleCase()}',
                    para: '${medicineInfo[index]}'.toCapitalized());
              },
            )
          ],
        ),
      ),
    );
  }
}
