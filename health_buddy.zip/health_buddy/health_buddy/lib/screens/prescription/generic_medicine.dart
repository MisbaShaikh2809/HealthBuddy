import 'package:flutter/material.dart';
import 'package:health_buddy/constants/colors.dart';
import 'package:health_buddy/utils/responsive.dart';
import 'package:health_buddy/widgets/generic_medicine_card.dart';

class GenericMedicine extends StatelessWidget {
  const GenericMedicine({super.key, required this.medicineList});
  final List medicineList;

  @override
  Widget build(BuildContext context) {
    print(medicineList);
    final width = MediaQuery.of(context).size.width * 0.01;
    final height = MediaQuery.of(context).size.height * 0.01;

    return Scaffold(
      backgroundColor: kPrimaryDark,
      body: SafeArea(
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.all(0),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(Icons.arrow_back_ios),
                ),
              ],
            ),
            Container(
              height: height * 3,
            ),
            const SizedBox(
              height: 20,
            ),
            Text(
              "Generic Medicines",
              style: TextStyle(
                  fontSize: getHeadingSize(context),
                  color: Colors.white,
                  fontWeight: FontWeight.w600),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(
              height: 30,
            ),
            //CONTENT
            ListView.builder(
              shrinkWrap: true,
              itemCount: medicineList.length,
              itemBuilder: (context, index) {
                return GenericMedicineCard(
                    height: height, title: medicineList[index]);
              },
            ),
          ],
        ),
      ),
    );
  }
}
