import 'dart:io';

import 'package:flutter/material.dart';
import 'package:health_buddy/constants/colors.dart';
import 'package:health_buddy/services/api_service.dart';
import 'package:health_buddy/utils/responsive.dart';
import 'package:image_cropper/image_cropper.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key, required this.image});
  final CroppedFile image;

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  String docName = '';
  String patName = '';
  String reason = '';
  String from = '';

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height * 0.01;

    return Scaffold(
      backgroundColor: kPrimaryDark,
      body: FutureBuilder<String>(
          future: Api().extractTextFromImage(widget.image.path),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              String text = snapshot.data!;
              setValues(text);

              return SafeArea(
                child: ListView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 25, vertical: 20),
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.all(0),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: const Icon(Icons.arrow_back_ios),
                        ),
                        //save button
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Text(
                      'Scanned',
                      style:
                          TextStyle(fontSize: height * 2.5, color: Colors.grey),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(
                      "Doctor Notes",
                      style: TextStyle(
                          fontSize: getHeadingSize(context),
                          color: Colors.white,
                          fontWeight: FontWeight.w600),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    //CONTENT
                    Text(
                      text,
                      style: TextStyle(
                          fontSize: height * 2.4, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Text(
                      'Derived Insights',
                      style: TextStyle(
                        fontSize: height * 2.4,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15, vertical: 8),
                      margin: const EdgeInsets.only(bottom: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                      ),
                      child: Text(
                        'Doctor Name: $docName',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: height * 2.3,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15, vertical: 8),
                      margin: const EdgeInsets.only(bottom: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                      ),
                      child: Text(
                        'Reason for absense: $reason.',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: height * 2.3,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15, vertical: 8),
                      margin: const EdgeInsets.only(bottom: 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                      ),
                      child: Text(
                        'Duration: $from',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: height * 2.3,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 2,
                      ),
                    ),
                  ],
                ),
              );
            } else {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
          }),
    );
  }

  void setValues(String para) {
    //First
    para.replaceAll('\n', ' ');
    para.replaceAll(',', '.');

    //Logic

    List<String> list = para.split('.');

    for (int i = 0; i < list.length; i++) {
      if (list[i].startsWith('Doctor Name')) {
        docName = list[i].split(':')[1];
      } else if (list[i].startsWith('Please Excuse:')) {
        patName = list[i].split(':')[1];
      } else if (list[i].startsWith('Due to:')) {
        reason = list[i].split(':')[1];
      } else if (list[i].startsWith('From: ')) {
        from = list[i].split(':')[1];
      }
    }
  }
}
