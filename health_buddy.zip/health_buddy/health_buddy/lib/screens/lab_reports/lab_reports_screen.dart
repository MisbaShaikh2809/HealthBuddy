import 'package:flutter/material.dart';
import 'package:health_buddy/utils/responsive.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class LabReportsScreen extends StatelessWidget {
  const LabReportsScreen({super.key, required this.image});
  final CroppedFile image;

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height * 0.01;

    return Scaffold(
      body: SafeArea(
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 20),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.all(0),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(Icons.arrow_back_ios),
                ),
                //save button
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            Text(
              'Scanned Kidney Reports',
              style: TextStyle(fontSize: height * 2.5, color: Colors.grey),
            ),
            const SizedBox(
              height: 5,
            ),
            Text(
              "Lab Reports",
              style: TextStyle(
                  fontSize: getHeadingSize(context),
                  color: Colors.white,
                  fontWeight: FontWeight.w600),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(
              height: 30,
            ),

            //CONTENT
            Text(
              'Highlights: ',
              style: TextStyle(
                  fontSize: height * 2.5, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: height * 2,
            ),
            Text(
              '1. Size in mm: 10 \n 2. No. of kidney stones: 2',
              style: TextStyle(
                fontSize: height * 2.4,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(
              height: height * 3,
            ),
            //CIRCULAR CHART
            Container(
              height: height * 38,
              margin: const EdgeInsets.only(bottom: 35),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: const Color(0xFFE64A5E),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.only(
                      left: 20,
                      right: 20,
                      top: 20,
                    ),
                    child: Text(
                      'Severity',
                      style: TextStyle(
                        fontSize: height * 3,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  CircularPercentIndicator(
                    radius: 75.0,
                    lineWidth: 24.0,
                    animation: true,
                    percent: 0.8,
                    center: const Text(
                      '80%',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20.0,
                      ),
                    ),
                    circularStrokeCap: CircularStrokeCap.round,
                    backgroundColor: const Color(0xFFD0001B),
                    progressColor: const Color(0xFF6C000E),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
