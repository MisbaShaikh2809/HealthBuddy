import 'package:health_buddy/models/result_model.dart';
import 'package:health_buddy/screens/credits_page.dart';
import 'package:health_buddy/screens/saved_results_page.dart';
import 'package:health_buddy/services/network_status_service.dart';
import 'package:health_buddy/utils/responsive.dart';
import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:health_buddy/constants/colors.dart';
import 'package:health_buddy/main.dart';
import 'package:health_buddy/utils/save_name.dart';
import 'package:health_buddy/widgets/cards.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool isLoading = true;
  String name = '';

  void getName() {
    SaveName().getName().then((value) {
      setState(() {
        isLoading = false;
        name = value;
      });
    });
  }

  void setDatabase() {
    ResultModel.createDatabase().then((value) {
      setState(() {
        isLoading = false;
      });
    });
  }

  @override
  void initState() {
    super.initState();
    getName();
    //Initialize the database
    setDatabase();
  }

  @override
  Widget build(BuildContext context) {
    // final width = MediaQuery.of(context).size.width * 0.01;
    // final height = MediaQuery.of(context).size.height * 0.01;

    return Connect(
      child: ModalProgressHUD(
        inAsyncCall: isLoading,
        child: Scaffold(
          backgroundColor: kPrimaryDark,
          body: SafeArea(
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              children: [
                IconButton(
                  alignment: Alignment.topRight,
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const SavedResultPage(),
                      ),
                    );
                  },
                  icon: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          shape: BoxShape.circle, color: kCardColor),
                      child: const Icon(
                        Icons.history_rounded,
                        size: 30,
                      )),
                ),
                Container(
                  padding: const EdgeInsets.only(bottom: 30),
                  child: Text(
                    'Hello, $name 👋',
                    style: TextStyle(
                        fontSize: getHeadingSize(context),
                        fontFamily: 'Sora',
                        fontWeight: FontWeight.w600),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                //CARDS
                MainCard(
                  image: 'images/inspect.png',
                  title: 'Inpect Prescription',
                  subtitle:
                      'Instantly inspect any doctor’s handwritten prediction in a sec.',
                  avatarColor: korange,
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const Scanner(
                          title: "Prescription",
                        ),
                      ),
                    );
                  },
                ),
                MainCard(
                  image: 'images/analyze.png',
                  title: "Analyze Doctor's Notes",
                  subtitle: 'Scan and inspect doctor notes easily in a sec.',
                  avatarColor: kblue,
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const Scanner(
                          title: "Doctor's Notes",
                        ),
                      ),
                    );
                  },
                ),
                MainCard(
                  image: 'images/lab_report.png',
                  title: 'Examine Lab Reports',
                  subtitle:
                      'Examine and derive useful insighths from lab reports. ',
                  avatarColor: kred,
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const Scanner(
                                  title: "Lab Reports",
                                )));
                  },
                ),
                const SizedBox(
                  height: 80,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Future<void> addAll() async {
  //   var colRef = FirebaseFirestore.instance.collection('disease_data');
  //   List<Map<String, dynamic>> json = [
  //     {
  //       "Suggest Disease": "Cold",
  //       "Medicine Name": "Dolo 650@Vicks NyQuil Cold & Flu Nighttime Relief@",
  //       "Medicine Information":
  //           "Dolo 650 Tablet helps relieve pain and fever by blocking the release of certain chemical messengers responsible for fever and pain. It is used to treat headaches, migraine, nerve pain, toothache, sore throat, period (menstrual) pains, arthritis, muscle aches, and the common cold.@Nyquil Cold & Flu is a combination medicine used to treat headache, fever, body aches, cough, runny nose, sneezing, and sore throat caused by allergies, the common cold, or the flu.@",
  //       "Generic Name": "Acetaminophen@Dextromethorphan@",
  //       "Dosage":
  //           "Dolo comes in the form of 500 mg, 650 mg and 1000 mg.@30 mL orally every 6 hours not to exceed 120 mL daily or 2 capsules every 6 hours as needed not to exceed 8 capsules\/day.@",
  //       "Side Effect":
  //           "1. Stomach pain \n2. Nausea \n3. Vomiting @Signs of an allergic reaction, like rash; hives; itching; red, swollen, blistered, or peeling skin with or without fever; wheezing; tightness in the chest or throat; trouble breathing, swallowing, or talking; unusual hoarseness; or swelling of the mouth, face, lips, tongue, or throat.@",
  //       "Warning":
  //           "Dolo-650 Tablet 15's is not recommended for children below 6 years of age. If you are pregnant or breastfeeding, please consult a doctor before using Dolo-650 Tablet 15's. Avoid alcohol consumption with Dolo-650 Tablet 15's as it may increase the risk of liver damage.@Do not use this medicine if you have taken an MAO inhibitor in the past 14 days. A dangerous drug interaction could occur.Do not take more of this medication than is recommended. An overdose of acetaminophen can damage your liver or cause death.@"
  //     },
  //     {
  //       "Suggest Disease": "Allergies",
  //       "Medicine Name": "Hydroxyzine@Levocetirizine@",
  //       "Medicine Information":
  //           "Hydroxyzine is an antihistamine that reduces the effects of natural chemical histamine in the body. Histamine can produce symptoms of itching, or hives on the skin. Hydroxyzine may be used to treat allergic skin reactions such as hives or contact dermatitis.@Levocetirizine is an antihistamine that may be used to reduce allergy symptoms such as red, itchy, or watery eyes; a runny nose; sneezing; rashes; or reactions to insect bites or stings.@",
  //       "Generic Name": "hydoxyzine pamoate@levocetirizine@",
  //       "Dosage":
  //           "Take hydroxyzine exactly as prescribed by your doctor. Follow all directions on your prescription label. Your doctor may occasionally change your dose. Do not use this medicine in larger or smaller amounts or for longer than recommended.@5 mg orally once a day in the evening\nComments: Some patients may be adequately controlled on 2.5 mg orally once a day in the evening.@",
  //       "Side Effect":
  //           "Get emergency medical help if you have signs of an allergic reaction to hydroxyzine: hives; difficult breathing; swelling of your face, lips, tongue, or throat.@1. drowsiness 2. Tiredness\n3. Sinus pain\n4. Ear infection\n5. Cough\n6. Fever\n7. Nosebleed\n8. Vomiting 9. diarrhea 10. dry mouth 11.  weight gain@",
  //       "Warning":
  //           "Hydroxyzine may cause birth defects. Talk to you doctor before using hydroxyzine if pregnant or breastfeeding.Hydroxyzine can cause a serious heart problem, especially if you use certain medicines at the same time. Tell your doctor about all your current medicines and any you start or stop using.@You should not use levocetirizine if you are allergic to levocetirizine or cetirizine (Zyrtec). You should not take levocetirizine if you have end-stage kidney disease or if you are on dialysis. Any child younger than 12 years old with kidney disease should not take levocetirizine.@"
  //     },
  //     {
  //       "Suggest Disease": "Diarrhea",
  //       "Medicine Name": "Loperamide@Lomotil@",
  //       "Medicine Information":
  //           "Loperamide may be used to treat diarrhea or to reduce the amount of stool (poop) in people who have an ileostomy (which is when a surgeon re-routes your bowel through a small opening in your torso).Loperamide works by acting on mu-opioid receptors in the gut to slow down the movement of the gut, which in turn, slows down contractions in the intestines. This allows more time for fluids and nutrients to be absorbed back into the body, which makes the stool less watery and decreases the number of times you go to the toilet.@Atropine affects the body in many different ways, such as reducing spasms in the bladder, stomach, and intestines.Diphenoxylate is an antidiarrheal medication.@",
  //       "Generic Name": "loperamide@atropine @",
  //       "Dosage":
  //           "4 mg orally after the first loose stool, then 2 mg orally after each unformed stool\nMaximum dose: 16 mg per day@Follow all directions on your prescription label and read all medication guides or instruction sheets. Your doctor may occasionally change your dose. Use the medicine exactly as directed.@",
  //       "Side Effect":
  //           "1. Constipation 2. Dizziness 3. Drowsiness 4. Nausea 5. Stomach 6. Cramps@1. Severe constipation 2. Stomach pain or bloating 3. Ongoing or worsening 4. Diarrhea 5. diarrhea that is watery or bloody 6 . Severe pain in your upper stomach spreading to your back 7. Fever, flushing (warmth, redness, or tingly feeling)@",
  //       "Warning":
  //           "You should not use loperamide if you have ulcerative colitis, bloody or tarry stools, diarrhea with a high fever, or diarrhea caused by antibiotic medication. Loperamide is safe when used as directed. TAKING TOO MUCH LOPERAMIDE CAN CAUSE SERIOUS HEART PROBLEMS OR DEATH.@Do not use Lomotil if you have diarrhea that is caused by bacteria or by taking an antibiotic. You should not use Lomotil if you have a bile duct disorder causing jaundice (yellowing of your skin or eyes).@"
  //     },
  //     {
  //       "Suggest Disease": "Stroke",
  //       "Medicine Name": "Plavix@Clopidogre@",
  //       "Medicine Information":
  //           "Plavix prevents platelets in your blood from sticking together to form an unwanted blood clot that could block an artery. Plavix is used to lower your risk of having a stroke, blood clot, or serious heart problem after you've had a heart attack, severe chest pain (angina), or circulation problems.@Clopidogrel is used to lower your risk of having a stroke, blood clot, or serious heart problem after you've had a heart attack, severe chest pain (angina), or circulation problems. Clopidogrel may also be used for purposes not listed in this medication guide.@",
  //       "Generic Name": "clopidogrel@clopidogrel systemic@",
  //       "Dosage":
  //           "Loading dose: 300 mg orally once, Maintenance dose: 75 mg orally once a day, Duration of therapy: Optimal duration unknown.@Loading dose: 300 mg orally once\nMaintenance dose: 75 mg orally once a day\nDuration of therapy: Optimal duration unknown.@",
  //       "Side Effect":
  //           "Bleeding@The most commonly reported adverse effect was bleeding, including life threatening and fatal bleeding.@",
  //       "Warning":
  //           "Plavix keeps your blood from coagulating (clotting) to prevent unwanted blood clots that can occur with certain heart or blood vessel conditions. Because of this drug action, Plavix can make it easier for you to bleed, even from a minor injury. You should not use this medicine if you have any active bleeding such as a stomach ulcer or bleeding in the brain. Plavix increases your risk of bleeding, which can be severe or life-threatening.@Any active bleeding such as a stomach ulcer or bleeding in the brain.\nClopidogrel increases your risk of bleeding, which can be severe or life-threatening. Call your doctor or seek emergency medical attention if you have bleeding that will not stop, if you have blood in your urine, black or bloody stools, or if you cough up blood or vomit that looks like coffee grounds.\nDo not stop taking clopidogrel without first talking to your doctor, even if you have signs of bleeding. Stopping clopidogrel may increase your risk of a heart attack or stroke.@"
  //     },
  //     {
  //       "Suggest Disease": "Pneumonia",
  //       "Medicine Name": "Levofloxacin@ clarithromycin@",
  //       "Medicine Information":
  //           "Levofloxacin is an antibiotic that that may be used to treat different types of bacterial infections. Levofloxacin may also be used to treat people who have been exposed to anthrax or certain types of plague@Clarithromycin is a macrolide antibiotic that fights bacteria in your body.\nClarithromycin is used to treat many different types of bacterial infections affecting the skin and respiratory system.\nClarithromycin is also used together with other medicines to treat stomach ulcers caused by Helicobacter pylori.@",
  //       "Generic Name": "levofloxacin @ Clarithromyci@",
  //       "Dosage":
  //           "Take levofloxacin with water, at the same time each day. Drink extra fluids to keep your kidneys working properly while taking levofloxacin.\nYou may take levofloxacin tablets with or without food.@Take clarithromycin exactly as prescribed by your doctor. Follow all directions on your prescription label. Do not take this medicine in larger or smaller amounts or for longer than recommended.\nDo not use this medicine to treat any condition that has not been checked by your doctor. Do not share this medicine with another person, even if they have the same symptoms you have.You may take the regular tablets and oral suspension (liquid) with or without food.@",
  //       "Side Effect":
  //           "Get emergency medical help if you have signs of an allergic reaction to levofloxacin (hives, difficult breathing, swelling in your face or throat) or a severe skin reaction (fever, sore throat, burning in your eyes, skin pain, red or purple skin rash that spreads and causes blistering and peeling).@Get emergency medical help if you have signs of an allergic reaction to clarithromycin: (hives, difficult breathing, swelling in your face or throat) or a severe skin reaction (fever, sore throat, burning in your eyes, skin pain, red or purple skin rash that spreads and causes blistering and peeling).@",
  //       "Warning":
  //           "Levofloxacin can cause serious side effects, including tendon problems, nerve damage, serious mood or behavior changes, or low blood sugar.Stop using levofloxacin and call your doctor at once if you have symptoms such as: headache, hunger, irritability, numbness, tingling, burning pain, confusion, agitation, paranoia, problems with memory or concentration, thoughts of suicide, or sudden pain or movement problems in any of your joints.In rare cases, levofloxacin may cause damage to your aorta, which could lead to dangerous bleeding or death. Get emergency medical help if you have severe and constant pain in your chest, stomach, or back.@Take clarithromycin for the full prescribed length of time. Your symptoms may improve before the infection is completely cleared. Skipping doses may also increase your risk of further infection that is resistant to antibiotics. This medicine will not treat a viral infection such as the common cold or flu.You should not use this medicine if you are allergic to clarithromycin or similar antibiotics, if you have ever had jaundice or liver problems caused by taking this medicine, or if you have liver or kidney disease and are also taking colchicine.@"
  //     },
  //     {
  //       "Suggest Disease": "Conjunctivitis (Pinkeye)",
  //       "Medicine Name": "erythromycin@Tobrex@",
  //       "Medicine Information":
  //           "Erythromycin is an antibiotic that fights bacteria.Erythromycin ophthalmic (for the eyes) is used to treat bacterial infections of the eyes.Erythromycin ophthalmic may also be used for purposes not listed in this medication guide.@Tobramycin is an antibiotic that fights bacteria.Tobrex (for the eyes) is used to treat bacterial infections of the eyes. Tobrex will not treat a viral or fungal infection of the eye. Tobrex is for use in treating only bacterial infections.@",
  //       "Generic Name": "erythromycin ophthalmic@tobramycin ophthalmic@",
  //       "Dosage":
  //           "Gel: Apply a thin film to the affected area(s) once to 2 times a day@Tobrex is usually given as 1 to 2 drops into the affected eye every 4 hours. For a severe infection, you may need to use 2 drops every hour for a short time before reducing the dose and number of drops per day. Your doctor will tell you how long to keep using the medicine. Follow your doctor's dosing instructions very carefully.@",
  //       "Side Effect":
  //           "1. skin itching, redness, burning, or peeling 2. dry or oily skin.@1. Severe burning, stinging, or irritation after using this medicine. 2. Eye swelling, redness, severe discomfort, crusting or drainage (may be signs of infection).@",
  //       "Warning":
  //           "Diarrhea may be a sign of a new infection. Call your doctor if you have diarrhea that is watery or has blood in it.@Follow all directions on your medicine label and package. Tell each of your healthcare providers about all your medical conditions, allergies, and all medicines you use.@"
  //     },
  //     {
  //       "Suggest Disease": "Insomnia",
  //       "Medicine Name": "Trazodone@Ambien@",
  //       "Medicine Information":
  //           "Trazodone is an antidepressant that belongs to a group of drugs called serotonin receptor antagonists and reuptake inhibitors (SARIs). While trazodone is not a true member of the selective serotonin reuptake inhibitors (SSRIs) class of antidepressants, it does still share many properties of the SSRIs. Trazodone is used to treat major depressive disorder.@Ambien is a sedative, also called a hypnotic. Zolpidem affects chemicals in the brain that may be unbalanced in people with sleep problems insomnia).Ambien is used to treat insomnia. The immediate-release tablet is used to help you fall asleep when you first go to bed. The extended-release form, Ambien CR, which has a first layer that dissolves quickly to help you fall asleep, and a second layer that dissolves slowly to help you stay asleep.@",
  //       "Generic Name": "Trazodone@zolpidem systemic@",
  //       "Dosage":
  //           "Initial dose: 150 mg orally per day in divided doses; this may be increased by 50 mg orally per day every 3 to 4 days\nMaximum dose:\n-Inpatients: 600 mg\/day\n-Outpatients: 400 mg\/day@Take Ambien exactly as prescribed by your doctor. Follow all directions on your prescription label. Never take this medicine in larger amounts, or for longer than prescribed. The recommended doses of zolpidem are not the same in men and women, and this drug is not approved for use in children. Read all patient information, medication guides, and instruction sheets provided to you. Ask your doctor or pharmacist if you have any questions.@",
  //       "Side Effect":
  //           "1. Drowsiness, dizziness, tiredness 2. Swelling 3. Weight loss 4. Blurred vision 5. Diarrhea, constipation 6. Stuffy nose@1. Daytime drowsiness, dizziness, weakness, feeling \"drugged\" or light-headed. 2. Tired feeling, loss of coordination. 3.Stuffy nose, dry mouth, nose or throat irritation. 4. nausea, constipation, diarrhea, upset stomach@",
  //       "Warning":
  //           "You should not use trazodone if you are allergic to it, or if you are being treated with methylene blue injection. Do not use this medicine if you have taken an MAO inhibitor in the past 14 days. A dangerous drug interaction could occur. MAO inhibitors include isocarboxazid, linezolid, phenelzine, tranylcypromine and others.@Ambien may cause a severe allergic reaction. Stop taking this medicine and get emergency medical help if you have any of these signs of an allergic reaction: hives; difficulty breathing; swelling of your face, lips, tongue, or throat.@"
  //     },
  //     {
  //       "Suggest Disease": "Asthma",
  //       "Medicine Name": "Singulair@Prednisone@ ",
  //       "Medicine Information":
  //           "Singulair is a leukotriene (loo-koe-TRY-een) inhibitor. Leukotrienes are chemicals your body releases when you breathe in an allergen (such as pollen). These chemicals cause swelling in your lungs and tightening of the muscles around your airways, which can result in asthma symptoms.@Prednisone is a corticosteroid medicine used to decrease inflammation and  keep your immune system in check, if it is overactive. Prednisone is used to treat allergic disorders, skin conditions, ulcerative colitis, Crohn’s disease, arthritis, lupus, psoriasis, asthma, chronic obstructive pulmonary disease (COPD) and many more conditions.@",
  //       "Generic Name": "Montelukast systemic@Prednisone systemic@",
  //       "Dosage":
  //           "Usual Adult Dose of Singulair for Allergic Rhinitis: 10 mg orally once a day@Take prednisone exactly as prescribed by your doctor. Follow all directions on your prescription label. Your doctor may change your dose to make sure you get the best results. Do not take this medicine in larger or smaller amounts or for longer than recommended. Take prednisone with food.@",
  //       "Side Effect":
  //           "1. Stomach pain, diarrhea 2. Fever or other flu symptoms 3. Ear pain or full feeling, trouble hearing 4. Headache@1. Sleep problems (insomnia), mood changes. 2. Increased appetite, gradual weight gain. 3. Acne, increased sweating, dry skin, thinning skin, bruising or discoloration. 4. Slow wound healing. 5.Headache, dizziness, spinning sensation@",
  //       "Warning":
  //           "Some people using Singulair have had new or worsening mental problems. Stop taking montelukast and call your doctor right away if you have any unusual changes in mood or behavior (such as anger, aggression, confusion, sleep problems, compulsive behaviors, hallucinations, or suicidal thoughts or actions). Tell your doctor right away if you have signs of blood vessel inflammation: flu-like symptoms, severe sinus pain, a skin rash, numbness or a \"pins and needles\" feeling in your arms or legs.@Prednisone treats many different conditions such as allergic disorders, skin conditions, ulcerative colitis, arthritis, lupus, psoriasis, or breathing disorders.@"
  //     },
  //     {
  //       "Suggest Disease": "Body Pain",
  //       "Medicine Name": "Tramadol@Gabapentin@",
  //       "Medicine Information":
  //           "Tramadol is a strong pain medication used to treat moderate to severe pain that is not being relieved by other types of pain medicines. Tramadol is a synthetic opioid and acts in the brain and spine (central nervous system) to reduce the amount of pain you feel.@Gabapentin (Neurontin, Gralise, Horizant) is a medicine used to treat partial seizures, nerve pain from shingles and restless leg syndrome. It works on the chemical messengers in your brain and nerves.  Gabapentin is from a group of medicines called anticonvulsants. @",
  //       "Generic Name": "Tramadol@Gabapentin@",
  //       "Dosage":
  //           "Adults (17 years or older): 50 to 100 mg orally every 4 to 6 hours as needed for pain-For patients not requiring rapid onset of analgesic effect: Initial dose: 25 mg orally once a day; titrate in 25 mg increments every 3 days to reach a dose of 25 mg four times a day; thereafter increase by 50 mg as tolerated every 3 days. Maximum dose: 400 mg per day.@Initial dose: 300 mg orally on day one, 300 mg orally 2 times day on day two, then 300 mg orally 3 times a day on day three\nMaintenance dose: 300 to 600 mg orally 3 times a day\nMaximum dose: 3600 mg orally daily (in 3 divided doses)\n-Maximum time between doses in the 3 times a day schedule should not exceed 12 hours@",
  //       "Side Effect":
  //           "1. Constipation 2.Nausea and vomiting 3. Stomach pain 4. Dizziness 5. Drowsiness 6. Tiredness@1. Fever, chills, sore throat, body aches, unusual tiredness.\n2. Jerky movements\n3. Headache\n4. Double vision\nswelling of your legs and feet 5.Tremors@",
  //       "Warning":
  //           "Seizures have been reported in patients taking tramadol. Your risk of seizures is higher if you are taking higher doses than recommended. Seizure risk is also higher in those with a seizure disorder or those taking certain antidepressants or opioid medications. Tramadol should not be used if you are suicidal or prone to addiction.@Gabapentin can cause life-threatening breathing problems, especially if you already have a breathing disorder or if you use other medicines that can make you drowsy or slow your breathing. Seek emergency medical attention if you have very slow breathing.@"
  //     },
  //     {
  //       "Suggest Disease": "Cholesterol",
  //       "Medicine Name": "Atorvastatin@Simvastatin@",
  //       "Medicine Information":
  //           "Atorvastatin belongs to a group of drugs called HMG CoA reductase inhibitors, or \"statins.\"\nAtorvastatin is used together with diet to lower blood levels of \"bad\" cholesterol (low-density lipoprotein, or LDL), to increase levels of \"good\" cholesterol (high-density lipoprotein, or HDL), and to lower triglycerides (a type of fat in the blood).\nAtorvastatin is used to treat high cholesterol, and to lower the risk of stroke, heart attack, or other heart complications in people with type 2 diabetes, coronary heart disease, or other risk factors.@Simvastatin belongs to a group of drugs called HMG CoA reductase inhibitors, or \"statins.\" Simvastatin is used to lower blood levels of \"bad\" cholesterol (low-density lipoprotein, or LDL), to increase levels of \"good\" cholesterol (high-density lipoprotein, or HDL), and to lower triglycerides (a type of fat in the blood).@",
  //       "Generic Name": "Atorvastatin systemic@Simvastatin systemic@",
  //       "Dosage":
  //           "Take atorvastatin exactly as prescribed by your doctor. Follow all directions on your prescription label. Your doctor may occasionally change your dose to make sure you get the best results. Do not use this medicine in larger or smaller amounts or for longer than recommended.@Take simvastatin exactly as prescribed. Follow all directions on your prescription label. Never take this medicine in larger amounts, or for longer than prescribed. Taking too much of this medication may cause serious or life-threatening side effects.Simvastatin is usually taken at bedtime or with an evening meal. If you take simvastatin more than once daily, take it with meals. Your doctor may occasionally change your dose to make sure you get the best results.@",
  //       "Side Effect":
  //           "1. Joint pain 2. Stuffy nose 3.Sore throat 4. diarrhea\n5. Pain in your arms or legs.@1. Headache 2. Constipation, nausea, stomach pain 3. Cold symptoms such as stuffy nose, sneezing, sore throat.@",
  //       "Warning":
  //           "You should not take atorvastatin if you are pregnant or breastfeeding, or if you have liver disease. Stop taking this medication and tell your doctor right away if you become pregnant. Serious drug interactions can occur when certain medicines are used together with atorvastatin. Tell each of your healthcare providers about all medicines you use now, and any medicine you start or stop using.@In rare cases, simvastatin can cause a condition that results in the breakdown of skeletal muscle tissue, potentially leading to kidney failure. Call your doctor right away if you have unexplained muscle pain, tenderness, or weakness especially if you also have fever, unusual tiredness, and dark colored urine.\nNever take simvastatin in larger amounts, or for longer than recommended by your doctor. Follow your doctor's dosing instructions very carefully. Taking too much of this medication may cause serious or life-threatening side effects.@"
  //     }
  //   ];
  //   for (var e in json) {
  //     var medicineName = e['Medicine Name'];
  //     if (medicineName != null) {
  //       List<String> list = medicineName.split("@");
  //       //Convert every medicine name to lower case
  //       for (var i = 0; i < list.length; i++) {
  //         list[i] = list[i].toLowerCase();
  //       }
  //       list.removeLast();
  //       e['Medicine Name'] = list;
  //     }
  //     var medicineInfo = e['Medicine Information'];
  //     if (medicineInfo != null) {
  //       List<String> list = medicineInfo.split("@");
  //       //Convert every medicine name to lower case
  //       for (var i = 0; i < list.length; i++) {
  //         list[i] = list[i].toLowerCase();
  //       }
  //       list.removeLast();
  //       e['Medicine Information'] = list;
  //     }
  //     var genericNames = e["Generic Name"];
  //     if (genericNames != null) {
  //       List<String> list = genericNames.split("@");
  //       //Convert every medicine name to lower case
  //       for (var i = 0; i < list.length; i++) {
  //         list[i] = list[i].toLowerCase();
  //       }

  //       list.removeLast();
  //       e['Generic Name'] = list;
  //     }
  //     var dosages = e["Dosage"];
  //     if (dosages != null) {
  //       List<String> list = dosages.split("@");
  //       //Convert every medicine name to lower case
  //       for (var i = 0; i < list.length; i++) {
  //         list[i] = list[i].toLowerCase();
  //       }
  //       list.removeLast();
  //       e['Dosage'] = list;
  //     }
  //     var sideEffects = e["Side Effect"];
  //     if (sideEffects != null) {
  //       List<String> list = sideEffects.split("@");
  //       //Convert every medicine name to lower case
  //       for (var i = 0; i < list.length; i++) {
  //         list[i] = list[i].toLowerCase();
  //       }
  //       list.removeLast();
  //       e['Side Effect'] = list;
  //     }

  //     var warnings = e["Warning"];
  //     if (warnings != null) {
  //       List<String> list = warnings.split("@");
  //       //Convert every medicine name to lower case
  //       for (var i = 0; i < list.length; i++) {
  //         list[i] = list[i].toLowerCase();
  //       }
  //       list.removeLast();
  //       e['Warning'] = list;
  //     }
  //   }

  //   int i = 0;
  //   for (var e in json) {
  //     print("Adding $i");
  //     await colRef.add(e);
  //     print("Added $i");
  //     i++;
  //   }
  // }
}
