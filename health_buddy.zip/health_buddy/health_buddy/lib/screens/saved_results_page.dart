import 'package:health_buddy/models/result_model.dart';
import 'package:health_buddy/utils/responsive.dart';
import 'package:flutter/material.dart';
import 'package:health_buddy/constants/colors.dart';
import 'package:health_buddy/widgets/cards.dart';
import 'package:health_buddy/widgets/history_card.dart';


class SavedResultPage extends StatefulWidget {
  const SavedResultPage({super.key});

  @override
  State<SavedResultPage> createState() => _SavedResultPageState();
}

class _SavedResultPageState extends State<SavedResultPage> {
  Future<List<ResultModel>>? _results;

  void getData() {
    _results = ResultModel.getData();
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      backgroundColor: kPrimaryDark,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {
            setState(() {
              getData();
            });
          },
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            children: [
              Row(
                children: [
                  IconButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: const Icon(Icons.arrow_back_ios_new)),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Saved Results',
                      style: TextStyle(
                          fontSize: getHeadingSize(context),
                          fontFamily: 'Sora',
                          fontWeight: FontWeight.w600),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(
                      width: 15,
                    ),
                    //Delete button
                    GestureDetector(
                      onTap: () async {
                        //Show confirmation dialog
                        showDialog(
                          context: context,
                          builder: (context) {
                            return AlertDialog(
                              title: const Text('Delete all results?'),
                              content: const Text(
                                  'This action cannot be undone. Are you sure you want to delete all results?'),
                              actions: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                  child: const Text('Cancel'),
                                ),
                                TextButton(
                                  onPressed: () async {
                                    //Delete all results
                                    await ResultModel.deleteAll().then((value) {
                                      //Refresh the page
                                      setState(() {
                                        getData();
                                      });
                                      Navigator.pop(context);
                                    });
                                  },
                                  child: const Text('Delete'),
                                ),
                              ],
                            );
                          },
                        );
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: ksecondaryDark,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: const EdgeInsets.all(10),
                        child: const Icon(Icons.delete),
                      ),
                    ),
                  ],
                ),
              ),
              FutureBuilder<List<ResultModel>>(
                future: _results,
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    if (snapshot.data!.isEmpty) {
                      return Padding(
                        padding: EdgeInsets.only(
                            top: MediaQuery.of(context).size.height * 0.3),
                        child: const Center(
                          child: Text(
                            'Results will be saved here',
                            style: TextStyle(
                                fontSize: 20,
                                fontFamily: 'Sora',
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      );
                    }
                    return ListView.builder(
                      reverse: true,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: snapshot.data!.length,
                      itemBuilder: (context, index) {
                        ResultModel data = snapshot.data![index];
                        return HistoryCard(
                          prescription: data.prescription.toString(),
                          date: data.timestamp,
                        );
                        //return Container();
                      },
                    );
                  } else {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }
                },
              ),
              //CARDS
              const SizedBox(
                height: 80,
              ),
              //HistoryCard(),
            ],
          ),
        ),
      ),
    );
  }
}
