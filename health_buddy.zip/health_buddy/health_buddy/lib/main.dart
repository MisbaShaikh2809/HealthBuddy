import 'package:camera/camera.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:health_buddy/constants/colors.dart';
import 'package:health_buddy/firebase_options.dart';
import 'package:health_buddy/models/result_model.dart';
import 'package:health_buddy/screens/lab_reports/lab_reports_screen.dart';
import 'package:health_buddy/screens/notes/notes_screen.dart';
import 'package:health_buddy/screens/prescription/main_result_screen.dart';
import 'package:health_buddy/utils/wrapper.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sqflite/sqflite.dart';

late List<CameraDescription> _cameras;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      name: "HealthBuddy", options: DefaultFirebaseOptions.currentPlatform);
  _cameras = await availableCameras();

  runApp(const SkinApp());
}

class SkinApp extends StatefulWidget {
  const SkinApp({super.key});

  @override
  State<SkinApp> createState() => _SkinAppState();
}

class _SkinAppState extends State<SkinApp> {
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    //create database
    createDb();

    setState(() {
      isLoading = false;
    });
  }

  Future<void> createDb() async {
    //initialize the database

    await ResultModel.createDatabase();
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
            fontFamily: "Sora",
            //Dark Theme
            brightness: Brightness.dark,
            useMaterial3: true),
        home: const Wrapper());
  }
}

/// Scanner is the Main Application.
class Scanner extends StatefulWidget {
  final String title;

  /// Default Constructor
  const Scanner({Key? key, required this.title}) : super(key: key);

  @override
  State<Scanner> createState() => _ScannerState();
}

class _ScannerState extends State<Scanner> {
  late CameraController controller;
  bool isFlashOn = false;

  @override
  void initState() {
    super.initState();

    controller = CameraController(_cameras[0], ResolutionPreset.max);
    controller.initialize().then((_) {
      if (!mounted) {
        return;
      }
      setState(() {});
    }).catchError((Object e) {
      if (e is CameraException) {
        switch (e.code) {
          case 'CameraAccessDenied':
            print('User denied camera access.');
            break;
          default:
            print('Handle other errors.');
            break;
        }
      }
    });
    isFlashOn = controller.value.flashMode == FlashMode.torch;
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void toggle() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width * 0.01;
    final height = MediaQuery.of(context).size.height * 0.01;
    if (!controller.value.isInitialized) {
      return Container();
    }
    // return AspectRatio(
    // aspectRatio: controller.value.aspectRatio,
    return Scaffold(
      body: Stack(fit: StackFit.expand, children: [
        CameraPreview(controller),
        // cameraOverlay(
        //     padding: 50, aspectRatio: 1, color: const Color(0x55000000)),
        Container(
          margin: const EdgeInsets.only(top: 50),
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            // mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // IconButton(
              //     onPressed: () {
              //       Navigator.pop(context);
              //     },
              //     icon: const Icon(Icons.close)),
              Container(
                // margin: EdgeInsets.only(left: width * 10, right: width * 10),
                padding: EdgeInsets.symmetric(
                    horizontal: width * 4, vertical: width * 2.2),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(40),
                ),
                child: Text(
                  'Scanning for: ${widget.title}',
                  style: TextStyle(
                      fontFamily: 'Sora',
                      color: Colors.black,
                      fontSize: width * 3,
                      fontWeight: FontWeight.w600),
                ),
              ),
              IconButton(
                onPressed: () {
                  //Toggle flash light
                  if (isFlashOn) {
                    controller.setFlashMode(FlashMode.off);
                    setState(() {
                      isFlashOn = false;
                    });
                  } else {
                    controller.setFlashMode(FlashMode.torch);
                    setState(() {
                      isFlashOn = true;
                    });
                  }
                },
                icon: Icon(isFlashOn ? Icons.flash_on : Icons.flash_off),
              )
            ],
          ),
        ),
        //Upload from gallery button
        Positioned(
          bottom: height * 18,
          left: width * 24,
          child: GestureDetector(
            onTap: () {
              ImagePicker()
                  .pickImage(
                source: ImageSource.gallery,
              )
                  .then((pickedFile) async {
                if (pickedFile == null) return;
                //Compress the image
                await cropImage(pickedFile);
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(40),
              ),
              child: Row(
                children: const [
                  Icon(
                    Icons.image,
                    color: Color(0xFF313131),
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Text(
                    'Upload from Gallery',
                    style: TextStyle(
                        fontFamily: 'Sora',
                        color: Color(0xFF313131),
                        fontSize: 14,
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ),
        ),
        //Capture
        Positioned(
          bottom: height * 5,
          left: width * 40,
          child: SizedBox(
            width: 70,
            height: 70,
            child: TextButton(
              onPressed: () {
                //Take picture
                controller.takePicture().then((XFile file) async {
                  //Compress the image
                  await cropImage(file);
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
              child: const Icon(Icons.camera, color: Colors.black, size: 30),
            ),
          ),
        ),
        // Positioned(bottom: 20, left: 50, child: buildToggleButton()),
      ]),
    );
  }

  Future<void> cropImage(XFile? pickedFile) async {
    if (pickedFile != null) {
      final croppedFile = await ImageCropper().cropImage(
        sourcePath: pickedFile.path,
        compressFormat: ImageCompressFormat.jpg,
        compressQuality: 20,
        uiSettings: [
          AndroidUiSettings(
              toolbarTitle: 'Resize',
              toolbarColor: kPrimaryDark,
              toolbarWidgetColor: Colors.white,
              initAspectRatio: CropAspectRatioPreset.original,
              lockAspectRatio: false),
        ],
      );
      if (croppedFile != null) {
        //Navigate to the result page

        navigate(croppedFile);
      }
    }
  }

  void navigate(CroppedFile croppedFile) {
    if (widget.title == "Prescription") {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => MainPrescriptionScreen(
                    image: croppedFile,
                    // result: result,
                  )));
    } else if (widget.title == "Doctor's Notes") {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => NotesScreen(
                    image: croppedFile,
                  )));
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => LabReportsScreen(
            image: croppedFile,
          ),
        ),
      );
    }
  }
}
