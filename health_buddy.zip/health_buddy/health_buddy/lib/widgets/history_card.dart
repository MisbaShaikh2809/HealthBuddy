import 'package:flutter/material.dart';
import 'package:health_buddy/constants/colors.dart';
import 'package:health_buddy/screens/prescription/main_result_screen.dart';


class HistoryCard extends StatelessWidget {
  final String prescription;
  final String date;
  const HistoryCard({
    Key? key, required this.prescription, required this.date,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        //go to results screen again
        print('tapped');
        Navigator.push(context, MaterialPageRoute(builder: (context) => MainPrescriptionScreen(image: null, pred: prescription,),),);
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: kCardColor,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              prescription, 
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold,),
            ),
            const SizedBox(height: 25,),
            Text(getDateFromTimestamp(date)),
          ],
        ),
      ),
    );
  }

  String getDateFromTimestamp(String date) {
    final DateTime dateTime =
        DateTime.fromMillisecondsSinceEpoch(int.parse(date));
    return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
  }
}

