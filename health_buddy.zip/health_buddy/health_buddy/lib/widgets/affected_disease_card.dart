import 'package:flutter/material.dart';

import '../constants/colors.dart';

class AffectedDiseaseCard extends StatelessWidget {
  final String diseaseName;
  const AffectedDiseaseCard({
    Key? key,
    required this.diseaseName,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double height = MediaQuery.of(context).size.width * 0.01;
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      height: height * 30,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: kCardColor,
      ),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Container(
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                image: DecorationImage(
                  image: NetworkImage(
                    'https://cdn.shopify.com/s/files/1/0084/8143/9824/products/BOOK_6_EYEOFWISDOM_6f239528-767b-432c-acb1-e082b74a2073_530x@2x.jpg?v=1632333385',
                  ),
                  fit: BoxFit.fitHeight,
                ),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Container(
              margin: const EdgeInsets.only(left: 10),
              child: Text(
                diseaseName,
                style: TextStyle(
                  fontSize: height * 6,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
