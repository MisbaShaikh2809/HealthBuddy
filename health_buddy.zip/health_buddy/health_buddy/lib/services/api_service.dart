import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class Api {
  //Extract text from jpg image using google vision
  Future<String> extractTextFromImage(String imagePath) async {
    print('Extracting text from image');
    // return "dolo 650";
    //Get image
    final image = File(imagePath);
    //Get image bytes
    final imageBytes = await image.readAsBytes();
    //Get base64 encoded image
    final base64Image = base64Encode(imageBytes);
    //Get api key
    const apiKey = "AIzaSyDYEGgY0A1C425JO8Ut-n8XauxH0K5WykQ";
    //Get url
    const url = "https://vision.googleapis.com/v1/images:annotate?key=$apiKey";
    //Get request body
    final requestBody = {
      "requests": [
        {
          "image": {"content": base64Image},
          "features": [
            {"type": "TEXT_DETECTION"}
          ]
        }
      ]
    };
    //Make request
    final response = await http.post(Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(requestBody));
    print(response);
    //Get response body
    final responseBody = jsonDecode(response.body);
    print(responseBody["responses"]);
    //Get text
    final text =
        responseBody["responses"][0]["textAnnotations"][0]["description"];
    //Return text
    return text;
  }
}
