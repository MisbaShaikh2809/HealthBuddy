import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:health_buddy/constants/descriptions.dart';

class Db {
  //Get most probable diseases
  Future<List<Map<String, dynamic>>> getMostProbableDisease(
      String prescription) async {
    prescription = prescription.toLowerCase();
    //Get prescription words
    List<String> medicines = getMedicines();
    List<String> presentMedicines = ["A"];

    for (int i = 0; i < medicines.length; i++) {
      if (prescription.contains(medicines[i])) {
        presentMedicines.add(medicines[i]);
      }
    }

    var result = await FirebaseFirestore.instance
        .collection("disease_data")
        .where("Medicine Name", arrayContainsAny: presentMedicines)
        .get();

    return result.docs.map((e) => e.data()).toList();
  }
}
