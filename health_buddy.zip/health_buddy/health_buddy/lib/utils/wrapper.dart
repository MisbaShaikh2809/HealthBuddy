import 'package:flutter/material.dart';
import 'package:health_buddy/screens/home_screen.dart';
import 'package:health_buddy/screens/welcome_screen.dart';
import 'package:health_buddy/utils/save_name.dart';

class Wrapper extends StatelessWidget {
  const Wrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<bool>(
      stream: SaveName().checkName(),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          if (snapshot.data!) {
            return const HomeScreen();
          } else {
            return const WelcomeScreen();
          }
        } else {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }
      },
    );
  }
}
