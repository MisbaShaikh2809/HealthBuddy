import 'package:flutter/material.dart';

Color kPrimaryDark = const Color(0xFF1C1C25);
Color ksecondaryDark = const Color(0xFF373842);
Color kCardColor = const Color(0xFF292A33);
Color kSelected = const Color(0xFF4B4C58);
Color korange = const Color(0xFFF88342);
Color kblue = const Color(0xFF527AEE);
Color kred = const Color(0xFFDA485B);
Color kPurple = const Color(0xFF9D5CFF);
Color kGreen = const Color(0xFF00E56A);
