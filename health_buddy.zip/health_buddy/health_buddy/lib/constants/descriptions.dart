List<Map<String, dynamic>> json = [
  {
    "Suggest Disease": "Cold",
    "Medicine Name": "Dolo 650@Vicks NyQuil Cold & Flu Nighttime Relief@",
    "Medicine Information":
        "Dolo 650 Tablet helps relieve pain and fever by blocking the release of certain chemical messengers responsible for fever and pain. It is used to treat headaches, migraine, nerve pain, toothache, sore throat, period (menstrual) pains, arthritis, muscle aches, and the common cold.@Nyquil Cold & Flu is a combination medicine used to treat headache, fever, body aches, cough, runny nose, sneezing, and sore throat caused by allergies, the common cold, or the flu.@",
    "Generic Name": "Acetaminophen@Dextromethorphan@",
    "Dosage":
        "Dolo comes in the form of 500 mg, 650 mg and 1000 mg.@30 mL orally every 6 hours not to exceed 120 mL daily or 2 capsules every 6 hours as needed not to exceed 8 capsules\/day.@",
    "Side Effect":
        "1. Stomach pain \n2. Nausea \n3. Vomiting @Signs of an allergic reaction, like rash; hives; itching; red, swollen, blistered, or peeling skin with or without fever; wheezing; tightness in the chest or throat; trouble breathing, swallowing, or talking; unusual hoarseness; or swelling of the mouth, face, lips, tongue, or throat.@",
    "Warning":
        "Dolo-650 Tablet 15's is not recommended for children below 6 years of age. If you are pregnant or breastfeeding, please consult a doctor before using Dolo-650 Tablet 15's. Avoid alcohol consumption with Dolo-650 Tablet 15's as it may increase the risk of liver damage.@Do not use this medicine if you have taken an MAO inhibitor in the past 14 days. A dangerous drug interaction could occur.Do not take more of this medication than is recommended. An overdose of acetaminophen can damage your liver or cause death.@"
  },
  {
    "Suggest Disease": "Allergies",
    "Medicine Name": "Hydroxyzine@Levocetirizine@",
    "Medicine Information":
        "Hydroxyzine is an antihistamine that reduces the effects of natural chemical histamine in the body. Histamine can produce symptoms of itching, or hives on the skin. Hydroxyzine may be used to treat allergic skin reactions such as hives or contact dermatitis.@Levocetirizine is an antihistamine that may be used to reduce allergy symptoms such as red, itchy, or watery eyes; a runny nose; sneezing; rashes; or reactions to insect bites or stings.@",
    "Generic Name": "hydoxyzine pamoate@levocetirizine@",
    "Dosage":
        "Take hydroxyzine exactly as prescribed by your doctor. Follow all directions on your prescription label. Your doctor may occasionally change your dose. Do not use this medicine in larger or smaller amounts or for longer than recommended.@5 mg orally once a day in the evening\nComments: Some patients may be adequately controlled on 2.5 mg orally once a day in the evening.@",
    "Side Effect":
        "Get emergency medical help if you have signs of an allergic reaction to hydroxyzine: hives; difficult breathing; swelling of your face, lips, tongue, or throat.@1. drowsiness 2. Tiredness\n3. Sinus pain\n4. Ear infection\n5. Cough\n6. Fever\n7. Nosebleed\n8. Vomiting 9. diarrhea 10. dry mouth 11.  weight gain@",
    "Warning":
        "Hydroxyzine may cause birth defects. Talk to you doctor before using hydroxyzine if pregnant or breastfeeding.Hydroxyzine can cause a serious heart problem, especially if you use certain medicines at the same time. Tell your doctor about all your current medicines and any you start or stop using.@You should not use levocetirizine if you are allergic to levocetirizine or cetirizine (Zyrtec). You should not take levocetirizine if you have end-stage kidney disease or if you are on dialysis. Any child younger than 12 years old with kidney disease should not take levocetirizine.@"
  },
  {
    "Suggest Disease": "Diarrhea",
    "Medicine Name": "Loperamide@Lomotil@",
    "Medicine Information":
        "Loperamide may be used to treat diarrhea or to reduce the amount of stool (poop) in people who have an ileostomy (which is when a surgeon re-routes your bowel through a small opening in your torso).Loperamide works by acting on mu-opioid receptors in the gut to slow down the movement of the gut, which in turn, slows down contractions in the intestines. This allows more time for fluids and nutrients to be absorbed back into the body, which makes the stool less watery and decreases the number of times you go to the toilet.@Atropine affects the body in many different ways, such as reducing spasms in the bladder, stomach, and intestines.Diphenoxylate is an antidiarrheal medication.@",
    "Generic Name": "loperamide@atropine @",
    "Dosage":
        "4 mg orally after the first loose stool, then 2 mg orally after each unformed stool\nMaximum dose: 16 mg per day@Follow all directions on your prescription label and read all medication guides or instruction sheets. Your doctor may occasionally change your dose. Use the medicine exactly as directed.@",
    "Side Effect":
        "1. Constipation 2. Dizziness 3. Drowsiness 4. Nausea 5. Stomach 6. Cramps@1. Severe constipation 2. Stomach pain or bloating 3. Ongoing or worsening 4. Diarrhea 5. diarrhea that is watery or bloody 6 . Severe pain in your upper stomach spreading to your back 7. Fever, flushing (warmth, redness, or tingly feeling)@",
    "Warning":
        "You should not use loperamide if you have ulcerative colitis, bloody or tarry stools, diarrhea with a high fever, or diarrhea caused by antibiotic medication. Loperamide is safe when used as directed. TAKING TOO MUCH LOPERAMIDE CAN CAUSE SERIOUS HEART PROBLEMS OR DEATH.@Do not use Lomotil if you have diarrhea that is caused by bacteria or by taking an antibiotic. You should not use Lomotil if you have a bile duct disorder causing jaundice (yellowing of your skin or eyes).@"
  },
  {
    "Suggest Disease": "Stroke",
    "Medicine Name": "Plavix@Clopidogre@",
    "Medicine Information":
        "Plavix prevents platelets in your blood from sticking together to form an unwanted blood clot that could block an artery. Plavix is used to lower your risk of having a stroke, blood clot, or serious heart problem after you've had a heart attack, severe chest pain (angina), or circulation problems.@Clopidogrel is used to lower your risk of having a stroke, blood clot, or serious heart problem after you've had a heart attack, severe chest pain (angina), or circulation problems. Clopidogrel may also be used for purposes not listed in this medication guide.@",
    "Generic Name": "clopidogrel@clopidogrel systemic@",
    "Dosage":
        "Loading dose: 300 mg orally once, Maintenance dose: 75 mg orally once a day, Duration of therapy: Optimal duration unknown.@Loading dose: 300 mg orally once\nMaintenance dose: 75 mg orally once a day\nDuration of therapy: Optimal duration unknown.@",
    "Side Effect":
        "Bleeding@The most commonly reported adverse effect was bleeding, including life threatening and fatal bleeding.@",
    "Warning":
        "Plavix keeps your blood from coagulating (clotting) to prevent unwanted blood clots that can occur with certain heart or blood vessel conditions. Because of this drug action, Plavix can make it easier for you to bleed, even from a minor injury. You should not use this medicine if you have any active bleeding such as a stomach ulcer or bleeding in the brain. Plavix increases your risk of bleeding, which can be severe or life-threatening.@Any active bleeding such as a stomach ulcer or bleeding in the brain.\nClopidogrel increases your risk of bleeding, which can be severe or life-threatening. Call your doctor or seek emergency medical attention if you have bleeding that will not stop, if you have blood in your urine, black or bloody stools, or if you cough up blood or vomit that looks like coffee grounds.\nDo not stop taking clopidogrel without first talking to your doctor, even if you have signs of bleeding. Stopping clopidogrel may increase your risk of a heart attack or stroke.@"
  },
  {
    "Suggest Disease": "Pneumonia",
    "Medicine Name": "Levofloxacin@ clarithromycin@",
    "Medicine Information":
        "Levofloxacin is an antibiotic that that may be used to treat different types of bacterial infections. Levofloxacin may also be used to treat people who have been exposed to anthrax or certain types of plague@Clarithromycin is a macrolide antibiotic that fights bacteria in your body.\nClarithromycin is used to treat many different types of bacterial infections affecting the skin and respiratory system.\nClarithromycin is also used together with other medicines to treat stomach ulcers caused by Helicobacter pylori.@",
    "Generic Name": "levofloxacin @ Clarithromyci@",
    "Dosage":
        "Take levofloxacin with water, at the same time each day. Drink extra fluids to keep your kidneys working properly while taking levofloxacin.\nYou may take levofloxacin tablets with or without food.@Take clarithromycin exactly as prescribed by your doctor. Follow all directions on your prescription label. Do not take this medicine in larger or smaller amounts or for longer than recommended.\nDo not use this medicine to treat any condition that has not been checked by your doctor. Do not share this medicine with another person, even if they have the same symptoms you have.You may take the regular tablets and oral suspension (liquid) with or without food.@",
    "Side Effect":
        "Get emergency medical help if you have signs of an allergic reaction to levofloxacin (hives, difficult breathing, swelling in your face or throat) or a severe skin reaction (fever, sore throat, burning in your eyes, skin pain, red or purple skin rash that spreads and causes blistering and peeling).@Get emergency medical help if you have signs of an allergic reaction to clarithromycin: (hives, difficult breathing, swelling in your face or throat) or a severe skin reaction (fever, sore throat, burning in your eyes, skin pain, red or purple skin rash that spreads and causes blistering and peeling).@",
    "Warning":
        "Levofloxacin can cause serious side effects, including tendon problems, nerve damage, serious mood or behavior changes, or low blood sugar.Stop using levofloxacin and call your doctor at once if you have symptoms such as: headache, hunger, irritability, numbness, tingling, burning pain, confusion, agitation, paranoia, problems with memory or concentration, thoughts of suicide, or sudden pain or movement problems in any of your joints.In rare cases, levofloxacin may cause damage to your aorta, which could lead to dangerous bleeding or death. Get emergency medical help if you have severe and constant pain in your chest, stomach, or back.@Take clarithromycin for the full prescribed length of time. Your symptoms may improve before the infection is completely cleared. Skipping doses may also increase your risk of further infection that is resistant to antibiotics. This medicine will not treat a viral infection such as the common cold or flu.You should not use this medicine if you are allergic to clarithromycin or similar antibiotics, if you have ever had jaundice or liver problems caused by taking this medicine, or if you have liver or kidney disease and are also taking colchicine.@"
  }
];

//Return list of all medicines
List<String> getMedicines() {
  Set<String> listAll = {};
  for (var e in json) {
    String data = e["Medicine Name"];
    var list = data.split("@");
    list.removeWhere((element) => element.isEmpty);

    //convert to lower case
    for (int i = 0; i < list.length; i++) {
      list[i] = list[i].toLowerCase();
    }
    listAll.addAll(list);
  }
  return listAll.toList();
}
